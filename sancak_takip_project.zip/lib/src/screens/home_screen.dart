import 'package:flutter/material.dart';
import '../services/firestore_service.dart';
import '../services/auth_service.dart';
import '../models/transaction_model.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _fire = FirestoreService();
  final _auth = AuthService();

  @override
  Widget build(BuildContext context) {
    final user = _auth.currentUser;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ödemelerim'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await _auth.signOut();
              Navigator.pushReplacementNamed(context, '/');
            },
          )
        ],
      ),
      body: StreamBuilder<List<TransactionModel>>(
        stream: _fire.transactionsForUserStream(user?.uid ?? ''),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('Yaklaşan veya kayıtlı ödeme bulunmuyor'));
          }

          final items = snapshot.data!;
          return ListView.builder(
            itemCount: items.length,
            itemBuilder: (context, index) {
              final t = items[index];
              final daysLeft = t.odemeTarihi.difference(DateTime.now()).inDays;
              return Card(
                child: ListTile(
                  title: Text('\${t.eczane} — \${t.productName}'),
                  subtitle: Text('Ödeme: \${t.odemeTarihi.toLocal().toString().split(' ')[0]} • Kalan: \${daysLeft} gün'),
                  trailing: Text(t.durum),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
