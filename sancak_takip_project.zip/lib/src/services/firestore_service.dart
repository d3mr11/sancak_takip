import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/transaction_model.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Future<void> addTransaction(Map<String, dynamic> data) async {
    await _db.collection('transactions').add(data);
  }

  Stream<List<TransactionModel>> transactionsForUserStream(String userId) {
    return _db
      .collection('transactions')
      .where('bolgeMuduruId', isEqualTo: userId)
      .where('durum', whereIn: ['odunmedi', 'gecikti'])
      .snapshots()
      .map((snap) => snap.docs.map((d) => TransactionModel.fromMap(d.id, _mapFromDoc(d.data()))).toList());
  }

  Map<String, dynamic> _mapFromDoc(Map<String, dynamic> d) {
    final map = Map<String, dynamic>.from(d);
    if (map['satisTarihi'] is Timestamp) map['satisTarihi'] = (map['satisTarihi'] as Timestamp).toDate().toIso8601String();
    if (map['odemeTarihi'] is Timestamp) map['odemeTarihi'] = (map['odemeTarihi'] as Timestamp).toDate().toIso8601String();
    return map;
  }
}
