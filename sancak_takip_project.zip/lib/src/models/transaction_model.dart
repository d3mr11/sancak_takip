class TransactionModel {
  final String id;
  final String eczane;
  final String productId;
  final String productName;
  final int adet;
  final DateTime satisTarihi;
  final int vadeGun;
  final DateTime odemeTarihi;
  final String bolgeMuduruId;
  final String durum;

  TransactionModel({
    required this.id,
    required this.eczane,
    required this.productId,
    required this.productName,
    required this.adet,
    required this.satisTarihi,
    required this.vadeGun,
    required this.odemeTarihi,
    required this.bolgeMuduruId,
    required this.durum,
  });

  factory TransactionModel.fromMap(String id, Map<String, dynamic> map) {
    return TransactionModel(
      id: id,
      eczane: map['eczane'] ?? '',
      productId: map['productId'] ?? '',
      productName: map['productName'] ?? '',
      adet: map['adet'] ?? 0,
      satisTarihi: map['satisTarihi'] != null ? DateTime.parse(map['satisTarihi']) : DateTime.now(),
      vadeGun: map['vadeGun'] ?? 30,
      odemeTarihi: map['odemeTarihi'] != null ? DateTime.parse(map['odemeTarihi']) : DateTime.now(),
      bolgeMuduruId: map['bolgeMuduruId'] ?? '',
      durum: map['durum'] ?? 'odunmedi',
    );
  }
}
