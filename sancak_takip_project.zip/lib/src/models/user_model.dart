class UserModel {
  final String id;
  final String name;
  final String role;
  final String email;
  final String? fcmToken;

  UserModel({required this.id, required this.name, required this.role, required this.email, this.fcmToken});

  factory UserModel.fromMap(String id, Map<String, dynamic> map) {
    return UserModel(
      id: id,
      name: map['name'] ?? '',
      role: map['role'] ?? 'bolge_muduru',
      email: map['email'] ?? '',
      fcmToken: map['fcmToken'],
    );
  }
}
