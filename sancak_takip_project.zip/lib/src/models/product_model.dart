class ProductModel {
  final String id;
  final String name;
  final String barcode;
  final String company;
  final num price;

  ProductModel({required this.id, required this.name, required this.barcode, required this.company, required this.price});

  factory ProductModel.fromMap(String id, Map<String, dynamic> map) {
    return ProductModel(
      id: id,
      name: map['name'] ?? '',
      barcode: map['barcode'] ?? '',
      company: map['company'] ?? '',
      price: map['price'] ?? 0,
    );
  }
}
