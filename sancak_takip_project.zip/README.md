# Sancak Takip - Ready-to-build project

This repository is a ready-to-build Flutter project for the SANCAK TAKİP app (vade/ödeme tracking).
It contains source code, Firebase Cloud Functions, and a Codemagic workflow to produce an APK.

IMPORTANT: This project **does not include** Firebase private configuration files.
You must configure Firebase and add `google-services.json` and `GoogleService-Info.plist`,
or run `flutterfire configure` to generate `firebase_options.dart`.

## Quick start

1. Install Flutter: https://flutter.dev/docs/get-started/install
2. Open terminal in project folder.
3. Run:
   - `flutter pub get`
4. Configure Firebase:
   - Install Firebase CLI and login: `npm install -g firebase-tools` and `firebase login`
   - In project root: run `flutterfire configure` (choose your Firebase project and add Android/iOS apps)
   - This will create `lib/firebase_options.dart`. Alternatively place your `google-services.json` in `android/app` and `GoogleService-Info.plist` in `ios/Runner`.
5. Deploy Cloud Functions (optional for notifications):
   - `cd functions`
   - `npm install`
   - `firebase deploy --only functions`
6. Build APK locally:
   - `flutter build apk --release`
   - APK will be at `build/app/outputs/flutter-apk/app-release.apk`

## Codemagic
A `codemagic.yaml` workflow is included to produce an APK automatically when you connect the repo to Codemagic.

## Notes
- The app expects Firestore collections: `users`, `transactions`, `products`.
- Admin must create user documents in `users` (role = admin or bolge_muduru) and optionally save `fcmToken` for push notifications.
- Default vade (term) is 30 days but can be changed per transaction.

If you want, I can:
- Fill the repository with sample data generator script,
- Create GitHub-ready commit instructions,
- Or guide you step-by-step while you run commands.

