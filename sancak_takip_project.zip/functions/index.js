const functions = require('firebase-functions');
const admin = require('firebase-admin');
admin.initializeApp();
const db = admin.firestore();

exports.dailyPaymentCheck = functions.pubsub.schedule('0 8 * * *')
  .timeZone('Europe/Istanbul')
  .onRun(async (context) => {
    const today = new Date();
    const threeDaysLater = new Date();
    threeDaysLater.setDate(today.getDate() + 3);

    const snap = await db.collection('transactions')
      .where('durum', 'in', ['odunmedi'])
      .get();

    const userMessages = {};

    snap.forEach(doc => {
      const data = doc.data();
      const odeme = data.odemeTarihi ? new Date(data.odemeTarihi) : null;
      if (!odeme) return;
      let key = data.bolgeMuduruId;
      if (!userMessages[key]) userMessages[key] = [];

      if (odeme >= today && odeme <= threeDaysLater) {
        userMessages[key].push({title: 'Ödeme yaklaşıyor', body: `${data.eczane} - ${odeme.toISOString().split('T')[0]}`} );
      }
      if (odeme < today) {
        userMessages[key].push({title: 'Ödeme gecikti', body: `${data.eczane} - ${odeme.toISOString().split('T')[0]}`} );
      }
    });

    const promises = [];
    for (const uid in userMessages) {
      const udoc = await db.collection('users').doc(uid).get();
      if (!udoc.exists) continue;
      const user = udoc.data();
      if (!user || !user.fcmToken) continue;
      const payload = {
        notification: {
          title: 'Ödeme uyarıları',
          body: userMessages[uid].map(m=>m.body).join(' | ')
        }
      };
      promises.push(admin.messaging().sendToDevice(user.fcmToken, payload));
    }

    await Promise.all(promises);
    return null;
  });
