# How to seed sample data (manual steps)

Open Firebase Console -> Firestore -> Create collections:

1) users
- Create a document with ID = auto or specific UID from Firebase Authentication
Fields:
  name: 'Admin User'
  role: 'admin'
  email: 'admin@example.com'

Create documents for bolge muduru (region managers):
  name: 'Hasan Demir'
  role: 'bolge_muduru'
  email: 'hasan@example.com'
  fcmToken: '' (empty until device registers)

2) products
3) transactions

When creating transactions, set:
- eczane (string)
- productId (string)
- productName (string)
- adet (int)
- satisTarihi (ISO string)
- vadeGun (int)
- odemeTarihi (ISO string)
- bolgeMuduruId (user document id)
- durum ('odunmedi' or 'odendi')
